
const dns = require("dns");

dns.setServers(["8.8.8.8", "1.1.1.1"]);

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");

const User = require("./models/User");
const Officer = require("./models/Officer");

dotenv.config();

const createOfficer = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);

        console.log("MongoDB connected");

        const badgeNumber = "B12345";

        const existingOfficer = await Officer.findOne({ badgeNumber });

        if (existingOfficer) {
            console.log("Officer with this badge number already exists");
            process.exit(0);
        }

        const passwordHash = await bcrypt.hash(badgeNumber, 10);

        const user = await User.create({
            username: "officer01",
            email: "officer01@crms.com",
            passwordHash,
            role: "officer",
            isActive: true
        });

        const officer = await Officer.create({
            userId: user._id,
            officerId: "OFF001",
            badgeNumber: badgeNumber,
            name: "CRMS Officer",
            rank: "Inspector",
            department: "Law and Order",
            station: "Central Police Station",
            phoneNumber: "9876543210",
            address: "CRMS Police Station",
            joiningDate: new Date(),
            status: "active"
        });

        console.log("Officer created successfully");
        console.log("Username:", user.username);
        console.log("Initial password:", badgeNumber);
        console.log("Officer ID:", officer.officerId);

        await mongoose.connection.close();
        process.exit(0);

    } catch (error) {
        console.error("Error creating officer:", error);

        await mongoose.connection.close();
        process.exit(1);
    }
};

createOfficer();